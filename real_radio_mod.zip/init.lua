local tracks = { "music1", "music2", "music3" }
local current_track = {}

minetest.register_node("real_radio:player", {
    description = "Радио-проигрыватель",
    tiles = {
        "radio_top.png",
        "radio_side.png",
        "radio_side.png",
        "radio_side.png",
        "radio_side.png",
        "radio_side.png"
    },
    groups = {cracky=2},
    on_rightclick = function(pos, node, player, itemstack, pointed_thing)
        local name = player:get_player_name()
        current_track[name] = (current_track[name] or 0) + 1
        if current_track[name] > #tracks then current_track[name] = 1 end
        minetest.sound_play(tracks[current_track[name]], {
            to_player = name,
            gain = 1.0,
        })
        minetest.chat_send_player(name, "▶ " .. tracks[current_track[name]])
    end
})

minetest.register_craft({
    output = "real_radio:player",
    recipe = {
        {"default:steel_ingot", "default:mese_crystal", "default:steel_ingot"},
        {"default:glass",       "default:diamond",      "default:glass"},
        {"default:steel_ingot", "default:mese_crystal", "default:steel_ingot"}
    }
})